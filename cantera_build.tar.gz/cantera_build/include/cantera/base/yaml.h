#include "cantera/base/ct_defs.h"
#if CT_USE_SYSTEM_YAMLCPP
#include "yaml-cpp/yaml.h"
#else
#include "cantera/ext/yaml-cpp/yaml.h"
#endif
